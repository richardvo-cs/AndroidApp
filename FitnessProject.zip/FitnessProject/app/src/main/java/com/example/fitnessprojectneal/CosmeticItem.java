package com.example.fitnessprojectneal;

public class CosmeticItem {
    public String id;
    public String category; // Head, Face, Torso, Legs, Feet

    public CosmeticItem(String id, String category) {
        this.id = id;
        this.category = category;
    }
}
