package com.example.fitnessprojectneal;

public enum QuestType {
    STEP_GOAL,
    OTHER
}
